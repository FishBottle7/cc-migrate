//#region ../../packages/core/dist/src/ir.d.ts
/**
 * Unified Intermediate Representation (IR) v3 — 100% lossless (except encrypted).
 *
 * Pivot of the engine: every tool adapter reads its native storage into an IR
 * session and writes an IR session back. This is the sole N-adapter pivot
 * (not N² pairwise converters).
 *
 * Design consensus (docs/ir-protocol.md — binding for all adapters):
 *  - the IR is a LIVING protocol: when a source tool carries a concept the IR
 *    has no slot for, extending the IR (typed bucket / optional field) is the
 *    sanctioned move — never silent drops, extensions strings are a stopgap;
 *  - every piece of information must attach unambiguously to the entity it
 *    describes (session / message / block / single tool invocation) — no
 *    side-table keying by source ids that breaks under filter/reorder;
 *  - extensions are additive and optional; old adapters ignore new buckets.
 *
 * v3 breaking changes vs v2:
 *  - schemaVersion: 1 -> 2
 *  - Adds typed lossless buckets: goals / planModes / todos / unmappedEvents
 *    so DSH agent->IR is zero-loss (non-encrypted) and IR->agent discards
 *    only on the write side per target capability.
 *  - validateSession / messageToText updated; thinking preserved via
 *    ContentBlock.thinking; encrypted_content is the ONLY allowed drop.
 *
 * v3.1 additive changes (2026-08-29, codex 适配器调查驱动 — 全部为可选字段，旧适配器
 * 忽略即可，见 docs/ir-protocol.md「v3.1 登记」):
 *  - MessageRole 新增 'developer'（Codex/OpenAI Responses 的 developer 角色，
 *    与 system 不同——resume 回放时按原角色还原，跨工具由各写端自行降级）。
 *  - MigratedSession.meta?: 会话级适配器命名空间原生载荷（与 MigratedMessage.meta
 *    同契约），承载 codex session_meta 行（source/git/history_mode/…）等。
 *  - compaction[] 新增 replacementHistory?: MigratedMessage[]（codex
 *    CompactedItem.replacement_history 的类型化投影）与 meta?:（原生记录）。
 *  - unmappedEvents 语义泛化：不再限 DSH，泛指"源 harness 事件日志"
 *    (codex event_msg 行等)，seq = 源日志位置。
 *
 * v3.2 additive changes (2026-08-30, claude 适配器重写驱动 — 全部为可选字段，旧适配器
 * 忽略即可，见 docs/ir-protocol.md「v3.2 登记（claude）」):
 *  - ContentBlock.tool_result 新增 rawResult?: unknown（claude user.toolUseResult
 *    结构化工具结果原文，挂在块实体上，禁止按 toolUseId 旁表；zcode 可映射融合 output）。
 *  - MigratedSession 新增 tag? / permissionMode? / prLink? / worktreeSession? /
 *    costState?（claude 高频有语义的会话级元数据行提升为类型化字段）与
 *    sessionEvents?: MigratedUnmappedEvent[]（非对话的会话级行：claude system
 *    subtype 行等；seq = 源文件行号）。MigratedSidechain 同步获得 sessionEvents?。
 *  - systemPrompt 语义冻结进共识（#8）：源端无原生提示词则留空（claude 恒空）；
 *    目标端有原生通道走原生槽位（claude = 进程 flag --append-system-prompt），
 *    无通道才注入 IR 值；禁止把源提示词写进会话正文再叠加目标端系统提示词。
 *
 * v3.2 工程加固（同日，与形状无关——不改任何槽位，只收紧约束）：
 *  - IR_VERSION 协议版本常量 + Adapter.irVersion + registry 注册时硬闸门：
 *    每次协议变更（含加性扩展）必须 bump IR_VERSION，并同步全部内置适配器；
 *    落后版本的适配器无法注册（docs/ir-protocol.md「IR 版本与同步闸门」）。
 *  - validateSession 下探到块级（isContentBlock 闭集校验）、schemaVersion 严格必填
 *    =2、originTool 闭集、会话级 goals/planModes/todos/unmappedEvents/branchSummaries
 *    逐项校验（docs/ir-protocol.md「IR 加固清单」第一层）。
 *  - readSource 出口 / writeTarget 入口引擎级 validateSession 卡点（第三层）。
 *
 * v3.3 additive changes (2026-09-01, pi 适配器重写驱动 — 全部为可选字段，旧适配器
 * 忽略即可，见 docs/ir-protocol.md「v3.3 登记」与 docs/agents/pi.md §8/§14):
 *  - branchSummaries[] 条目扩形：{fromId, summary, anchorIndex?, time?, meta?} —
 *    pi branch_summary entry 全保真（anchorIndex 指向 messages[] 里的投影 user
 *    消息，anchor 契约同 compaction；meta 承原生残件 details/usage/fromHook/
 *    entryId/timestamp）。旧形状 {fromId, summary} 仍合法。
 *  - MigratedSession.meta.pi / MigratedMessage.meta.pi 命名空间（pi 原生载荷，
 *    其余适配器忽略）：会话级 header/settingsEvents/labels/customEntries/
 *    titleCleared；消息级 message（assistant 无槽位字段）/bash/customMessage/
 *    anchor/addedToolNames/usage。
 *  - pi 写端开始消费 compaction[]/branchSummaries[]（桶 → 原生 entry，anchor
 *    消息跳过防双写）；pi 读端 systemPrompt 恒空、写端恒不注入（pi 会话文件
 *    不存提示词正文，v3.2 #8 在 pi 端的执行细则）。
 */
type ToolId = 'dsh' | 'claude' | 'codex' | 'opencode' | 'pi' | 'zcode' | 'unknown';
/** Light metadata for a listed session (for GUI pickers / CLI --list). */
interface SessionMeta {
  tool: ToolId;
  sessionId: string;
  title?: string;
  createdAt?: number;
  /** Absolute path of the source artifact, when known. */
  sourcePath?: string;
  /** Absolute working directory the session ran under (source). */
  cwd?: string;
  /** True when the source store flags the session as archived (DSH workspace.json; codex archived_sessions/). */
  archived?: boolean;
  /** True when the native index registers the session but no rollout file exists yet (codex deferred creation — nothing to migrate). */
  deferredCreation?: boolean;
  /** Parent session when this session is a subagent (codex thread_spawn parent_thread_id). */
  parentSessionId?: string;
}
//#endregion
//#region ../../packages/core/dist/src/registry.d.ts
interface WriteResult {
  tool: ToolId;
  sessionId: string;
  /** Absolute path(s) written. */
  paths: string[];
}
//#endregion
//#region src/commands.d.ts
/** Tools this plugin can import FROM (target is always DSH). */
declare const SOURCE_TOOLS: ToolId[];
/** Structured failure — commands never let exceptions escape to the host. */
interface CommandError {
  ok: false;
  error: string;
}
interface ListSourcesResult {
  ok: true;
  tool: ToolId;
  sessions: SessionMeta[];
}
interface PreviewResult {
  ok: true;
  tool: ToolId;
  sessionId: string;
  /** Full offline text preview (host may truncate for display). */
  text: string;
}
interface ImportResult {
  ok: true;
  source: {
    tool: ToolId;
    sessionId: string;
  };
  target: WriteResult;
}
type ListSourcesOutcome = ListSourcesResult | CommandError;
type PreviewOutcome = PreviewResult | CommandError;
type ImportOutcome = ImportResult | CommandError;
/** GUI structured preview: payload on success, structured error on failure. */
type PreviewPayloadOutcome = PreviewPayload | CommandError;
interface ImportOptions {
  /** Source root override (where the source tool's sessions live). */
  srcRoot?: string;
  /** Working directory to stamp on the new DSH session (defaults to IR cwd). */
  targetCwd?: string;
  /** Override the new DSH session id (core generates one when omitted). */
  sessionId?: string;
  /** DSH sessions root override — tests/smoke pass a temp dir here. */
  root?: string;
  /** Cross-tool flattening: true turns hidden subagent transcripts into top-level messages. */
  flatten?: boolean;
  /** Keep harness-injected (synthetic) messages in the target session. */
  keepSynthetic?: boolean;
}
/** 结构化预览的消息块（IR ContentBlock 的 GUI 投影）。 */
interface PreviewBlockDto {
  t: 'text' | 'think' | 'tool_use' | 'tool_result' | 'file';
  text?: string;
  callId?: string;
  name?: string;
  mediaType?: string;
  isError?: boolean;
  truncated?: boolean;
}
/** 结构化预览的单条消息（IR MigratedMessage 的 GUI 投影）。 */
interface PreviewMessageDto {
  role: 'user' | 'assistant' | 'tool' | 'system' | 'developer';
  ts?: number;
  model?: string;
  synthetic?: boolean;
  /** harness 注入分类（codex AGENTS.md 指令、inter-agent 通信等非 synthetic 注入行）。 */
  injectionKind?: string;
  blocks: PreviewBlockDto[];
}
/** 子代理旁链（GUI 的子代理树：一层主干 + N 个节点，嵌套孙代已拍平）。 */
interface PreviewSidechainDto {
  agentId: string;
  agentType?: string;
  /** 派发该子代理的 tool_use 调用 id（渲染层据此把旁链挂到调用点下方）。 */
  parentCallId?: string;
  truncated?: boolean;
  messages: PreviewMessageDto[];
}
/** GUI 预览载荷（MigratedSession 的摘要 + 结构化消息投影）。 */
interface PreviewPayload {
  tool: ToolId;
  sessionId: string;
  title?: string;
  createdAt?: number;
  cwd?: string;
  model?: string;
  messageCount: number;
  sidechainCount: number;
  toolCallCount: number;
  hasSidechains: boolean;
  messages: PreviewMessageDto[];
  sidechains?: PreviewSidechainDto[];
}
/**
 * `/cc-migrate list-sources <tool> [--root <dir>]`
 *
 * Lists a source tool's sessions (title / time / id / cwd) via the shared
 * registry. Read-only.
 */
declare function listSources(tool: string, root?: string): Promise<ListSourcesOutcome>;
/**
 * `/cc-migrate preview <tool> <sessionId> [--root <dir>]`
 *
 * Parses the source session into IR and renders the offline text preview.
 * Read-only.
 */
declare function preview(tool: string, sessionId: string, root?: string): Promise<PreviewOutcome>;
/**
 * `/cc-migrate import <tool> <sessionId> [--src-root <dir>] [--cwd <dir>] [--root <dstRoot>]`
 *
 * Parses the source session into IR, then writes it into DSH's native
 * resumable storage as a BRAND-NEW session (fresh id; existing sessions
 * are never overwritten — core's write side guarantees this). The cwd
 * mapping is the DSH adapter's own: absolute target cwd → `--<projectKey>--`
 * layout, non-absolute/missing → `_no-cwd` (core degrades safely).
 */
declare function importSession(srcTool: string, srcSessionId: string, opts?: ImportOptions): Promise<ImportOutcome>;
//#endregion
//#region src/gui.d.ts
/**
 * Minimal structural type for the DSH host's GUI service. The host provides:
 *  - a mount point protocol (any container the host understands — DOM
 *    element, web component slot, id string; the wizard never touches it
 *    directly, only `mount()` does), and
 *  - the data channel forwarding to the command layer (the host decides
 *    WHERE the commands run; the GUI layer stays sandbox-clean).
 */
interface GuiHost {
  logger: {
    info(...args: unknown[]): void;
    warn(...args: unknown[]): void;
    error(...args: unknown[]): void;
  };
  /**
   * Mount `component` (a Vue component from @cc-migrate/ui) with `props`
   * into `container` (host-defined: DOM element or equivalent). Returns an
   * unmount function.
   */
  mount(container: unknown, component: unknown, props: Record<string, unknown>): () => void;
  /**
   * Data channel — all forwarded by the host to the command layer
   * (src/commands.ts). Shapes are the command layer's result/outcome types;
   * the GUI layer never imports core.
   */
  listSources(tool: string, root?: string): Promise<ListSourcesOutcome>;
  preview(tool: string, sessionId: string, root?: string): Promise<PreviewOutcome | PreviewPayloadOutcome>;
  importSession(srcTool: string, srcSessionId: string, opts?: ImportOptions): Promise<ImportOutcome>;
}
/** Tool card metadata (ui `ToolInfo` shape; structural, no ui import needed). */
interface GuiToolInfo {
  id: string;
  label: string;
  defaultRoot: string;
}
/** Wizard start options. */
interface WizardMountOptions {
  /** Host-side container (DOM element or equivalent) to mount into. */
  container: unknown;
  /** Default DSH sessions root (from plugin config `dstRoot`). */
  dstRoot?: string;
}
/** Result of `createSessionMigrateWizard`. */
interface WizardHandle {
  /** Runs the host unmount chain. Safe to call twice. */
  dispose(): void;
  /** The `MigrationBackend` object handed to MigrateWizard (host may reuse it). */
  backend: Record<string, unknown>;
}
/** Source tools the wizard offers (order = UI card order). */
declare const GUI_SOURCE_TOOLS: GuiToolInfo[];
/**
 * Build the `MigrationBackend` bridge (ui 组件契约) from a `GuiHost`.
 *
 * Mapping notes:
 *  - `listTools` — static metadata, no host round-trip.
 *  - `listSessions` — host channel → command layer `listSources`; empty
 *    array on unknown tool (the wizard's tool cards are already gated).
 *  - `preview` — host channel → command layer `previewPayload` (structured
 *    DTO; the GUI never consumes the CLI's flat text).
 *  - `migrate` — host channel → command layer `importSession`; the target
 *    is pinned to `dsh` (this plugin's one line: any tool → DSH), the
 *    wizard's dstTool choice is validated but only 'dsh' is accepted.
 *  - `pickDirectory` / `openPath` — host dialog services, optional: absent
 *    services log a warning instead of crashing (headless hosts).
 */
declare function createWizardBackend(host: GuiHost, opts?: {
  dstRoot?: string;
}): Record<string, unknown>;
/**
 * Mount the cc-migrate wizard into a host container.
 *
 * Composition choice: ui's ready-made `MigrateWizard` — it already assembles
 * ToolSelect → SessionPicker + SessionPreview → TargetConfig with the exact
 * 「选会话 → 预览 → 配置 → 写入」 flow this phase asks for (the desktop app
 * mounts it the same way with a `MigrationBackend` prop). Re-composing the
 * three pieces by hand would duplicate that flow state machine for zero gain.
 *
 * The component is loaded DYNAMICALLY so importing this module does not pull
 * `vue`/SFC sources at command-layer time: the host bundles the ui package
 * (source package), and a host without a bundled frontend just sees the
 * mount() promise reject with a clear reason. `opts.loadWizardComponent`
 * lets a host (or the headless smoke) inject its own bundled copy — the
 * default dynamic import is untouched.
 */
declare function createSessionMigrateWizard(host: GuiHost, opts?: WizardMountOptions & {
  loadWizardComponent?: () => Promise<unknown>;
}): Promise<WizardHandle>;
//#endregion
export { importSession as _, WizardMountOptions as a, CommandError as c, ImportResult as d, ListSourcesOutcome as f, SOURCE_TOOLS as g, PreviewResult as h, WizardHandle as i, ImportOptions as l, PreviewOutcome as m, GuiHost as n, createSessionMigrateWizard as o, ListSourcesResult as p, GuiToolInfo as r, createWizardBackend as s, GUI_SOURCE_TOOLS as t, ImportOutcome as u, listSources as v, preview as y };