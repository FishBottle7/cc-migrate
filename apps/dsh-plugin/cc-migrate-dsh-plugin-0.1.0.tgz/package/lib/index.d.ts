import { _ as importSession, c as CommandError, d as ImportResult, f as ListSourcesOutcome, g as SOURCE_TOOLS, h as PreviewResult, l as ImportOptions, m as PreviewOutcome, n as GuiHost, p as ListSourcesResult, u as ImportOutcome, v as listSources, y as preview } from "./gui-BrIw4CS1.js";
//#region src/index.d.ts
/**
 * Minimal structural type against the DSH host ctx (same discipline as the
 * opencode2dsh plugin): keeps this package free of a hard cordis dependency.
 *
 * `commands` is the minimal assumption about DSH's command service: a
 * `register(name, handler)` returning an unregister function. If the real
 * DSH host service ends up named/ shaped differently, only this interface
 * and the single `ctx.commands` access point need adjusting — the command
 * layer itself is host-agnostic. (DSH host service names follow the host;
 * see README.)
 */
interface PluginContext {
  logger: {
    info(...args: unknown[]): void;
    warn(...args: unknown[]): void;
    error(...args: unknown[]): void;
  };
  /**
   * dsh-commands 宿主契约（真机加载验证锚定，@deepseek-ai/dsh-commands 的
   * normalizeDefinition/normalizeResult）：register(definition) 收
   * {name, description, input?, recordInput?, handler}——description 必填
   * 非空（缺失时 normalizeDefinition 抛 TypeError 炸整棵插件树），handler
   * 收单个 invocation（rawInput = 命令名后的原始文本）、必须返回
   * CommandResult {kind, text}。返回注销函数（fiber 清理用）。
   */
  commands?: {
    register(definition: {
      name: string;
      description: string;
      input?: {
        hint: string;
        images?: boolean;
      };
      recordInput?: boolean;
      handler: (invocation: CommandInvocation) => Promise<CommandResult> | CommandResult;
    }): () => void;
  };
  /**
   * Optional GUI service (design.md Phase 3 §15): when the host exposes one,
   * the cc-migrate wizard mounts through it. Same structural-typing
   * discipline — see src/gui.ts's GuiHost for the full protocol. Hosts
   * without a GUI keep the commands-only behavior (backward compatible).
   */
  gui?: GuiHost;
  /** cordis fiber cleanup: the returned disposer runs on plugin unload. */
  effect?(fn: () => () => void): unknown;
}
/** Plugin config (bundle patch `config: {}` for now; reserved for GUI phase). */
interface SessionMigrateConfig {
  /** Default DSH sessions root override (defaults to ~/.dsh/sessions). */
  dstRoot?: string;
}
declare const name = "cc-migrate";
declare const inject: readonly ["commands"];
/** A slash-command invocation: argv-style tokens after the command name. */
interface CommandInvocation {
  /** Positional arguments (tool, sessionId, ...). */
  positionals: string[];
  /** --flag value pairs (--root X --cwd Y). */
  flags: Record<string, string | true>;
}
/** Parse `["claude", "--root", "X"]` into `{ positionals, flags }`. */
declare function parseArgs(argv: string[]): {
  positionals: string[];
  flags: Record<string, string | true>;
};
/** Format a listed session for one-line display in the host. */
declare function formatSessionLine(idx: number, m: {
  sessionId: string;
  title?: string;
  createdAt?: number;
  cwd?: string;
}): string;
/** Registered command names, for tests to assert against. */
declare const COMMAND_NAMES: readonly ["cc-migrate-list-sources", "cc-migrate-preview", "cc-migrate-import"];
/**
 * dsh-commands 宿主契约（真机加载验证锚定，@deepseek-ai/dsh-commands/lib/index.js
 * 的 normalizeDefinition/normalizeResult/dispatch）：
 *  - 命令名是扁平小写 `^[a-z][a-z0-9_-]*$`——没有「插件名 子命令」的层级语法，
 *    三个子命令因此各自注册为独立命令，`cc-migrate-` 前缀即命名空间。
 *  - definition 必须 {name, description(非空 string), handler}——缺
 *    description 在 normalizeDefinition 直接抛 TypeError 并炸整棵插件树
 *    （真机首装时踩过：mock ctx 的宽松形状没拦住这个）。
 *  - handler 收单个 invocation {rawInput, agent, attachments, signal}，
 *    rawInput = 命令名之后的原始文本（含前导空格，dispatch 前自行 split）。
 *  - 返回值必须 {kind:'success'|'error', text}——裸返回命令层结果对象
 *    会被 normalizeResult 当 TypeError 拒绝。
 */
interface CommandInvocation {
  /** 命令名之后的原始输入（未分词，含前导空格）。 */
  rawInput: string;
  agent?: unknown;
  attachments?: unknown;
  signal?: AbortSignal;
}
interface CommandResult {
  kind: 'success' | 'error';
  text: string;
}
/**
 * Plugin apply: registers the three cc-migrate commands (flat dsh-command
 * names — see COMMAND_NAMES 头注的宿主契约)。
 *
 * Each `commands.register` call returns an unregister function; every one is
 * routed through `ctx.effect` so the cordis fiber disposal unregisters all
 * of them on plugin reload/unload/shutdown. There are no timers and no
 * child processes — dispose is purely the unregister set.
 */
declare function apply(ctx: PluginContext, config?: SessionMigrateConfig): void;
//#endregion
export { COMMAND_NAMES, type CommandError, type ImportOptions, type ImportOutcome, type ImportResult, type ListSourcesOutcome, type ListSourcesResult, type PreviewOutcome, type PreviewResult, SOURCE_TOOLS, SessionMigrateConfig, apply, formatSessionLine, importSession, inject, listSources, name, parseArgs, preview };